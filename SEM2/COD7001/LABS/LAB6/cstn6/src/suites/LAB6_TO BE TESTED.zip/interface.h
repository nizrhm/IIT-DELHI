#ifndef INTERFACE_H
#define INTERFACE_H

#include <stdint.h>
#include <stdbool.h>

typedef enum { OBJ_INT, OBJ_PAIR } ObjType;

typedef struct Obj {
    ObjType type;
    bool marked;
    struct Obj* next;
    union {
        int value;
        struct { struct Obj *left, *right; } pair;
    };
} Obj;

typedef struct {
    int* line_map;
    int map_capacity;
} DebugMeta;

#define MAX_GLOBALS 256
#define MAX_STACK 1024
#define MAX_CALL_STACK 128

typedef struct {
    // Data Stack
    Obj** stack;
    int sp;
    int stack_capacity;
    
    // Call Stack (for CALL/RET)
    int call_stack[MAX_CALL_STACK];
    int csp; // Call Stack Pointer

    // Memory
    Obj* globals[MAX_GLOBALS]; 
    
    // Code & Execution
    int* program;
    int pc;
    int program_size;
    int fp; // Frame Pointer (for local vars/functions)

    // Metadata & Control
    DebugMeta debug_meta;
    bool breakpoints[1024];
    bool running;
    bool paused;

    // GC
    Obj* firstObject;
    int numObjects;
    int maxObjects;
} VM;

typedef enum { 
    PROC_FREE, PROC_STOPPED, PROC_RUNNING, 
    PROC_PAUSED, PROC_TERMINATED, PROC_ERROR 
} ProcState;

typedef struct {
    int pid;
    char filename[64];
    ProcState state;
    VM* vm;
    int exit_code;
} Process;

// API
Process* get_process(int pid);
VM* vm_create(int* bytecode, int size, int* lines);
void vm_free(VM* vm);
void vm_step(VM* vm);
void vm_run(VM* vm);
void vm_continue(VM* vm);
void vm_toggle_breakpoint(VM* vm, int line);
void vm_gc(VM* vm);
int vm_get_heap_count(VM* vm);
int compile_source(const char* filename, int** code_out, int* size_out, int** lines_out);
void start_debugger(int pid);

#endif