#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../interface.h"

// --- GC IMPLEMENTATION ---
void mark(Obj* root) {
    if (!root || root->marked) return;
    root->marked = true;
    if (root->type == OBJ_PAIR) { mark(root->pair.left); mark(root->pair.right); }
}
void vm_gc(VM* vm) {
    int prev = vm->numObjects;
    for (int i = 0; i < vm->sp; i++) mark(vm->stack[i]);
    for (int i = 0; i < MAX_GLOBALS; i++) if (vm->globals[i]) mark(vm->globals[i]);
    Obj** obj = &vm->firstObject;
    while (*obj) {
        if (!(*obj)->marked) {
            Obj* unreached = *obj; *obj = unreached->next; free(unreached); vm->numObjects--;
        } else { (*obj)->marked = false; obj = &(*obj)->next; }
    }
    vm->maxObjects = (vm->numObjects == 0) ? 8 : vm->numObjects * 2;
    printf("[GC] Reclaimed %d objects.\n", prev - vm->numObjects);
    fflush(stdout);
}
Obj* new_obj(VM* vm, ObjType type) {
    if (vm->numObjects >= vm->maxObjects) vm_gc(vm);
    Obj* o = malloc(sizeof(Obj));
    if(!o) { fprintf(stderr, "Fatal: OOM\n"); exit(1); }
    o->type = type; o->marked = false; o->next = vm->firstObject;
    vm->firstObject = o; vm->numObjects++;
    return o;
}

// --- VM CORE ---
VM* vm_create(int* bytecode, int size, int* lines) {
    VM* vm = malloc(sizeof(VM));
    vm->stack = malloc(sizeof(Obj*) * MAX_STACK);
    vm->stack_capacity = MAX_STACK;
    memset(vm->globals, 0, sizeof(vm->globals));
    memset(vm->breakpoints, 0, sizeof(vm->breakpoints));
    memset(vm->call_stack, 0, sizeof(vm->call_stack));
    
    vm->program = bytecode;
    vm->program_size = size;
    vm->debug_meta.line_map = lines;
    vm->sp = 0; vm->csp = 0; vm->pc = 0; vm->fp = 0;
    vm->running = true; vm->paused = false;
    vm->firstObject = NULL; vm->numObjects = 0; vm->maxObjects = 8; 
    return vm;
}

int get_pc_from_line(VM* vm, int line) {
    for (int i = 0; i < vm->program_size; i++) 
        if (vm->debug_meta.line_map[i] == line) return i;
    return -1;
}

void vm_toggle_breakpoint(VM* vm, int line) {
    int pc = get_pc_from_line(vm, line);
    if (pc != -1) {
        vm->breakpoints[pc] = !vm->breakpoints[pc];
        if (vm->breakpoints[pc]) printf("Breakpoint SET at Line %d\n", line);
        else printf("Breakpoint REMOVED at Line %d\n", line);
    } else {
        printf("Error: No instruction found at line %d\n", line);
    }
}

// Robust Stack Checks
#define CHECK_STACK_MIN(n) if (vm->sp < n) { printf("Error: Stack Underflow\n"); vm->running = false; return; }
#define CHECK_STACK_MAX() if (vm->sp >= MAX_STACK) { printf("Error: Stack Overflow\n"); vm->running = false; return; }
#define CHECK_CALL_STACK_MAX() if (vm->csp >= MAX_CALL_STACK) { printf("Error: Call Stack Overflow\n"); vm->running = false; return; }

void vm_step(VM* vm) {
    if (!vm->running || vm->pc >= vm->program_size) { vm->running = false; return; }
    
    int opcode = vm->program[vm->pc++]; // Safe fetch
    
    switch (opcode) {
        case 0x01: { // PUSH
            CHECK_STACK_MAX();
            int val = vm->program[vm->pc++]; 
            Obj* o = new_obj(vm, OBJ_INT); o->value = val; vm->stack[vm->sp++] = o; 
            break; 
        }
        case 0x02: // POP
            CHECK_STACK_MIN(1);
            vm->sp--; 
            break; 

        // MATH
        case 0x10: { CHECK_STACK_MIN(2); Obj* b=vm->stack[--vm->sp]; Obj* a=vm->stack[--vm->sp];
                     Obj* r=new_obj(vm, OBJ_INT); r->value = a->value + b->value; vm->stack[vm->sp++]=r; break; }
        case 0x11: { CHECK_STACK_MIN(2); Obj* b=vm->stack[--vm->sp]; Obj* a=vm->stack[--vm->sp];
                     Obj* r=new_obj(vm, OBJ_INT); r->value = a->value - b->value; vm->stack[vm->sp++]=r; break; }
        case 0x12: { CHECK_STACK_MIN(2); Obj* b=vm->stack[--vm->sp]; Obj* a=vm->stack[--vm->sp];
                     Obj* r=new_obj(vm, OBJ_INT); r->value = a->value * b->value; vm->stack[vm->sp++]=r; break; }
        case 0x13: { CHECK_STACK_MIN(2); Obj* b=vm->stack[--vm->sp]; Obj* a=vm->stack[--vm->sp];
                     if(b->value==0) {printf("Error: DivZero\n"); vm->running=false; return;}
                     Obj* r=new_obj(vm, OBJ_INT); r->value = a->value / b->value; vm->stack[vm->sp++]=r; break; }
        case 0x14: { CHECK_STACK_MIN(2); Obj* b=vm->stack[--vm->sp]; Obj* a=vm->stack[--vm->sp];
                     Obj* r=new_obj(vm, OBJ_INT); r->value = (a->value < b->value); vm->stack[vm->sp++]=r; break; }
        case 0x15: { CHECK_STACK_MIN(2); Obj* b=vm->stack[--vm->sp]; Obj* a=vm->stack[--vm->sp];
                     Obj* r=new_obj(vm, OBJ_INT); r->value = (a->value > b->value); vm->stack[vm->sp++]=r; break; }
        case 0x16: { CHECK_STACK_MIN(2); Obj* b=vm->stack[--vm->sp]; Obj* a=vm->stack[--vm->sp];
                     Obj* r=new_obj(vm, OBJ_INT); r->value = (a->value == b->value); vm->stack[vm->sp++]=r; break; }

        // VARIABLES (GLOBALS)
        case 0x31: { // LOAD
             int addr = vm->program[vm->pc++];
             if (addr < 0 || addr >= MAX_GLOBALS) { printf("Error: Global OOB\n"); vm->running=false; return; }
             Obj* val = vm->globals[addr];
             if(!val) { val = new_obj(vm, OBJ_INT); val->value = 0; }
             vm->stack[vm->sp++] = val; break;
        }
        case 0x32: { // STORE (Fixed Indentation)
             CHECK_STACK_MIN(1);
             int addr = vm->program[vm->pc++];
             if (addr < 0 || addr >= MAX_GLOBALS) { printf("Error: Global OOB\n"); vm->running=false; return; }
             vm->globals[addr] = vm->stack[--vm->sp]; 
             break;
        }

        // CONTROL FLOW
        case 0x21: { // JZ
             CHECK_STACK_MIN(1);
             int target = vm->program[vm->pc++];
             if (vm->stack[--vm->sp]->value == 0) vm->pc = target;
             break;
        }
        case 0x20: vm->pc = vm->program[vm->pc]; break; // JMP
        
        // --- LAB 4 EXTENSION: FUNCTIONS ---
        case 0x40: { // CALL target
            CHECK_CALL_STACK_MAX();
            int target = vm->program[vm->pc++];
            vm->call_stack[vm->csp++] = vm->pc; 
            vm->pc = target; 
            break;
        }
        case 0x41: { // RET
            if (vm->csp > 0) {
                vm->pc = vm->call_stack[--vm->csp]; 
            } else {
                vm->running = false;
                printf("[VM] Halted (Main Returned).\n");
                fflush(stdout);
            }
            break;
        }
        // ----------------------------------

        case 0x23: vm_gc(vm); break;
        case 0xFF: vm->running = false; printf("[VM] Halted.\n"); fflush(stdout); break;
        default: printf("Error: Unknown Opcode 0x%x\n", opcode); vm->running = false; break;
    }
}

void vm_continue(VM* vm) {
    vm->paused = false;
    while (vm->running) {
        if (!vm->paused && vm->breakpoints[vm->pc]) {
            printf("[VM] Hit Breakpoint at Line %d\n", vm->debug_meta.line_map[vm->pc]);
            vm->paused = true;
            return;
        }
        vm_step(vm);
        vm->paused = false; 
    }
}
void vm_run(VM* vm) { while (vm->running) vm_step(vm); }
int vm_get_heap_count(VM* vm) { return vm->numObjects; }