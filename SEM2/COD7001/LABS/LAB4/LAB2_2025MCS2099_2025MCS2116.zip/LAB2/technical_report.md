# **Technical Report: Implementation of a Minimal Debugger**  
### **Course Code: COD7001**

**Mayur Kamble** — 2025MCS2116  
**Nizaul Rahman** — 2025MCS2099

---

## **1. Introduction and Project Goal**

This report details the design and implementation of a minimal debugger, `minigdb`, developed for ELF binaries on a Linux platform. The project's primary goal was to implement core debugging functionalities—loading, execution control, breakpoint management, and inspection—using operating-system-level primitives, specifically the `ptrace` system call, without reliance on standard debugging tools like GDB.

Mandatory Functional Requirements implemented:

- Load and Execute  
- Breakpoints  
- Step and Continue  
- Register Inspection  
- Process Status Reporting  

Optional Extensions:

- **Memory Inspection**  
- **Shell Integration**

---

## **2. Architectural Design: The PTRACE Model**

The debugger uses a parent–child tracing model via `ptrace`.

### **2.1 Process Setup (Fork/Execve)**

1. Fork to create tracee  
2. Child runs `PTRACE_TRACEME`  
3. Child calls `execl()`, stops with `SIGTRAP`  
4. Parent waits via `waitpid()`  

---

## **3. Core Mechanism: Software Breakpoints**

Breakpoints are implemented through `PTRACE_PEEKTEXT` and `PTRACE_POKETEXT`.

### **3.1 Breakpoint Placement**

The INT3 instruction (`0xCC`) replaces the first byte of the target instruction.

Steps:

1. Read original word  
2. Save first byte  
3. Write `0xCC`  

### **3.2 Breakpoint Handling (Step-Over)**

1. Kernel stops on 0xCC  
2. RIP decremented by 1  
3. Original byte restored  
4. `PTRACE_SINGLESTEP` executed  
5. Breakpoint reinstalled  

---

## **4. Process Control and Inspection**

### **4.1 Execution Control**

- `PTRACE_CONT`  
- `PTRACE_SINGLESTEP`

### **4.2 Inspection**

- `PTRACE_GETREGS` for registers  
- `waitpid()` macros for state  

---

## **5. Handling PIE/ASLR**

Linux loads executables at randomized addresses. Symbol table addresses are RVAs.

### **5.1 Obtaining Real Target Address**

1. Stop after `execve`  
2. Read `/proc/<PID>/maps`  
3. Extract `.text` segment base  

### **5.2 Absolute Address Formula**

`Absolute Address = Base Address + RVA`


This ensures accurate memory access under ASLR.

---

## **6. Optional Extensions**

### **6.1 Memory Inspection**

Memory is read using `PTRACE_PEEKDATA`.

Command format (now correctly included):

`x /<count> 0xADDRESS`


This allows the user to inspect `<count>` bytes starting from a given address.

### **6.2 Shell Integration Enhancements**

- Trimming whitespace  
- Multi-argument parsing  
- Support for commands like the one above  

---

## **7. Conclusion**

The `minigdb` debugger demonstrates:

- Breakpoint management  
- Instruction stepping  
- Register inspection  
- Memory inspection  
- PIE/ASLR compatibility  
- Improved shell interface  

It achieves full debugger functionality using only the `ptrace` system call, making it both lightweight and educationally valuable.

---